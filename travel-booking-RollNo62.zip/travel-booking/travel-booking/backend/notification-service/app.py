from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for all domains

@app.route('/notify', methods=['POST'])
def notify():
    data = request.json
    if not data or 'message' not in data:
        return jsonify({"error": "Invalid request, 'message' is required"}), 400

    return jsonify({"status": "Notification Sent", "message": data["message"]})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
