from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for all domains

@app.route('/pay', methods=['POST'])
def pay():
    data = request.json
    if not data or 'amount' not in data:
        return jsonify({"error": "Invalid request, 'amount' is required"}), 400

    return jsonify({"status": "Payment Processed", "amount": data["amount"]})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
