from flask import Flask, jsonify, request
from flask_cors import CORS
import requests

app = Flask(__name__)
CORS(app)  # Enable CORS for all domains

@app.route('/book', methods=['POST'])
def book():
    data = request.json
    if not data or 'amount' not in data:
        return jsonify({"error": "Invalid request, 'amount' is required"}), 400

    # Payment Service Interaction
    payment_response = requests.post("http://payment-service:5000/pay", json={"amount": data["amount"]})
    
    # Notification Service Interaction
    notification_response = requests.post("http://notification-service:5000/notify", json={"message": "Booking Successful!"})
    
    return jsonify({
        "booking": "success",
        "payment": payment_response.json(),
        "notification": notification_response.json()
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
