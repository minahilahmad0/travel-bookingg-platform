CREATE TABLE bookings (
    id SERIAL PRIMARY KEY,
    amount DECIMAL NOT NULL,
    status VARCHAR(50)
);
