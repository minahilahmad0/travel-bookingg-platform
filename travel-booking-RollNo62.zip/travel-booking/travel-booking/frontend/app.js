document.getElementById('booking-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const amount = document.getElementById('amount').value;
    const responseDiv = document.getElementById('response');

    try {
        const response = await fetch('http://localhost:5001/book', {  // Use localhost instead of booking-service
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ amount }),
        });

        if (!response.ok) {
            throw new Error(`Error: ${response.statusText}`);
        }

        const data = await response.json();
       
 responseDiv.innerHTML = `
            <strong>Booking Result:</strong><br>
            <pre>${JSON.stringify(data.booking, null, 2)}</pre><br>
            <strong>Payment Result:</strong><br>
            <pre>${JSON.stringify(data.payment, null, 2)}</pre><br>
            <strong>Notification Result:</strong><br>
            <pre>${JSON.stringify(data.notification, null, 2)}</pre>
        `;

    } catch (error) {
        responseDiv.textContent = `Failed to fetch: ${error.message}`;
    }
});
