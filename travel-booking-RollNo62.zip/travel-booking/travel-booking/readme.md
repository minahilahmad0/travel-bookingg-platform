# Travel Booking Platform

This project implements a microservices-based travel booking platform using Docker, Flask, and Nginx. It includes services for booking, payment, and notifications, along with a frontend and database.

---
Project Directory Structure
travel-booking-platform/
├── backend/
│   ├── booking-service/
│   │   ├── app.py
│   │   ├── requirements.txt
│   │   └── Dockerfile
│   ├── payment-service/
│   │   ├── app.py
│   │   ├── requirements.txt
│   │   └── Dockerfile
│   └── notification-service/
│       ├── app.py
│       ├── requirements.txt
│       └── Dockerfile
├── db/
│   ├── init.sql
│   └── Dockerfile
├── frontend/
│   ├── index.html
│   ├── styles.css
│   ├── app.js
│   └── Dockerfile
├── docker-compose.yml
├── output.jpg
└── README.md


## Setup Guide
### Prerequisites

1. Install Docker and Docker Compose.
2. Clone the repository:
   bash
   git clone <repository-url>
   cd travel-booking-platform
   

### Build and Run Services
1. Build and start all services:
   bash
   docker-compose up --build
   

2. Access the services at the following URLs:
   - Frontend: [http://localhost:8080](http://localhost:8080)
   - Booking API: [http://localhost:5001](http://localhost:5001)
   - Payment API: [http://localhost:5002](http://localhost:5002)
   - Notification API: [http://localhost:5003](http://localhost:5003)

3. Stop services:
   bash
   docker-compose down

---

## Microservices

### 1. Booking Service

#### **Code**

- **app.py**
  - Handles booking requests and interacts with the Payment and Notification services.

#### **Dockerfile**

```dockerfile
FROM python:3.9-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY app.py .
CMD ["python", "app.py"]
```

#### **API**
- **Endpoint**: `/book`
- **Method**: POST
- **Input**: `{ "amount": <amount> }`
- **Output**: `{ "booking": "success", "payment": {...}, "notification": {...} }`

### 2. Payment Service

#### **Code**

- **app.py**
  - Processes payment requests.

#### **Dockerfile**

```dockerfile
FROM python:3.9-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY app.py .
CMD ["python", "app.py"]
```

#### **API**
- **Endpoint**: `/pay`
- **Method**: POST
- **Input**: `{ "amount": <amount> }`
- **Output**: `{ "status": "Payment Processed", "amount": <amount> }`

### 3. Notification Service

#### **Code**

- **app.py**
  - Sends notifications to users.

#### **Dockerfile**

```dockerfile
FROM python:3.9-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY app.py .
CMD ["python", "app.py"]
```

#### **API**
- **Endpoint**: `/notify`
- **Method**: POST
- **Input**: `{ "message": <message> }`
- **Output**: `{ "status": "Notification Sent", "message": <message> }`

---

## Database Service

### **Code**

- **init.sql**
  - Initializes the `bookings` table.

#### **Dockerfile**

```dockerfile
FROM postgres:13
ENV POSTGRES_USER=admin
ENV POSTGRES_PASSWORD=password
ENV POSTGRES_DB=travel
COPY init.sql /docker-entrypoint-initdb.d/
```

### **Usage**
- Automatically sets up the database on container startup.

---

## Frontend Service

### **Code**

- **index.html**
  - Basic UI for booking.
- **styles.css**
  - Styling for the frontend.
- **app.js**
  - Interacts with the Booking API.

#### **Dockerfile**

```dockerfile
FROM nginx:alpine
COPY . /usr/share/nginx/html
```

### **Usage**
- Accessible at [http://localhost:8080](http://localhost:8080).

---

## Docker Compose File

### **Code**

```yaml
version: '3.9'
services:
  booking-service:
    build: ./backend/booking-service
    ports:
      - "5001:5000"
    depends_on:
      - payment-service
      - notification-service

  payment-service:
    build: ./backend/payment-service
    ports:
      - "5002:5000"

  notification-service:
    build: ./backend/notification-service
    ports:
      - "5003:5000"

  database:
    build: ./db
    environment:
      POSTGRES_USER: admin
      POSTGRES_PASSWORD: password
      POSTGRES_DB: travel
    ports:
      - "5432:5432"

  frontend:
    build: ./frontend
    ports:
      - "8080:80"
```

---

## Inter-Service Communication

1. **Booking Service** interacts with:
   - **Payment Service** for payment processing.
   - **Notification Service** for sending notifications.

2. **Frontend** interacts with the **Booking Service** to create bookings.

---

## Testing

1. Start the services:
   ```bash
   docker-compose up --build
   ```

2. Access the frontend and submit a booking amount.
3. Verify inter-service communication through logs or API responses.

---

## Deployment

1. Push the code and Dockerfiles to a version control system (e.g., GitHub).
2. Deploy to a Docker-compatible cloud platform (e.g., AWS, Azure, or Google Cloud).
3. Set up a CI/CD pipeline for automated builds and deployments.

---

## Conclusion

This platform demonstrates how microservices, Docker, and inter-service communication can be used to build a scalable travel booking system.

